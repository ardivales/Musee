import 'dart:async';
import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:tp_musee/Models/Musee.dart';

import '../Models/Pays.dart';

class MuseeDatabase{
  static final MuseeDatabase instance = MuseeDatabase._init();
  static Database? database;
  MuseeDatabase._init();

  Future create() async {
    if(database != null) return database!;

    Directory path = await getApplicationDocumentsDirectory();
    String dbPath = join(path.path, "musee.db");

    database = await openDatabase(dbPath, version: 1, onCreate: _create);

    return database!;
  }
  
  Future _create(Database db, int version) async {
    /*
    Pays[codePays, nbhabitant]
    Musee[numMus, nomMus, nblivres, codePays#]
    Visiter[numMus#, jour#, nbvisiteurs]
    Moment[jour]
    Ouvrage[ISBN, nbPage, titre, codePays#]
    Bibliotheque[numMus#, ISBN#, dateAchat]
    */

    await db.execute("""
            CREATE TABLE PAYS (
              codePays TEXT PRIMARY KEY, 
              nbhabitant INTEGER NOT NULL
            )""");

    await db.execute("""
            CREATE TABLE MUSEE (
              numMus INTEGER PRIMARY KEY,
              nomMus TEXT NOT NULL,
              nblivres INTEGER NOT NULL,
              codePays TEXT NOT NULL,
              FOREIGN KEY (codePays) REFERENCES PAYS (codePays)
            )""");

    await db.execute("""
            CREATE TABLE OUVRAGE (
              isbn TEXT PRIMARY KEY,
              nbPage INTEGER NOT NULL,
              titre TEXT NOT NULL,
              codePays TEXT NOT NULL,
              FOREIGN KEY (codePays) REFERENCES PAYS (codePays)
            )""");

    await db.execute("""
            CREATE TABLE BIBLIOTHEQUE (
              dateAchat TEXT NOT NULL,
              numMus INTEGER NOT NULL,
              isbn TEXT NOT NULL,
              FOREIGN KEY (numMus) REFERENCES MUSEE (numMus),
              FOREIGN KEY (isbn) REFERENCES PAYS (isbn)
              CONSTRAINT pk_numMus_isbn PRIMARY KEY(numMus, isbn)
            )""");

    await db.execute("""
            CREATE TABLE MOMENT (
              jour TEXT PRIMARY KEY
            )""");    
        
    await db.execute("""
            CREATE TABLE VISITER (
              jour TEXT NOT NULL,
              numMus INTEGER NOT NULL,
              nbvisiteurs INTEGER NOT NULL,
              FOREIGN KEY (numMus) REFERENCES MUSEE (numMus),
              FOREIGN KEY (jour) REFERENCES MOMENT (jour)
              CONSTRAINT pk_numMus_jour PRIMARY KEY(numMus, jour)
            )""");

    
  }

  Future close() async{
    final db = await instance.create();
    db.close();
  }

  Future<int> insertPays(Pays pays) async {
    final db = await instance.create();
    return await db.insert("PAYS", pays.toJson());
  }

  Future<List<Pays>> getPays() async{
    final db = await instance.create();
    // final result = await db.rawQuery('SELECT * FROM $tableBase ORDER BY $orderBy');
    List result = await db.query("PAYS", orderBy: 'codePays ASC');
    print ('result getPays $result');
    
    return result.map((json)=>Pays.fromJson(json)).toList();
    
  }

  Future<List<Musee>> getMusees() async{
    final db = await instance.create();
    List result = await db.query("MUSEE", orderBy: 'numMus ASC');
    print ('result getMusee $result');
    
    return result.map((json)=>Musee.fromJson(json)).toList();
    
  }
}