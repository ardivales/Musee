import 'package:flutter/material.dart';
import 'package:tp_musee/Database/MuseeDatabase.dart';
import 'package:tp_musee/Screens/ListeMusees.dart';
import 'package:tp_musee/Screens/PaysScreen.dart';
import 'package:tp_musee/main.dart';

import '../Models/Pays.dart';

class ListePays extends StatefulWidget {

  const ListePays({ Key? key }) : super(key: key);
  @override
  State<ListePays> createState() => _ListePaysState();
}

class _ListePaysState extends State<ListePays> {
  List<Pays> listPays = [];
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    getPays();

  }
  @override
  void dispose(){
    MuseeDatabase.instance.close();
    super.dispose();
  }

  Future getPays() async{
    setState(() => isLoading = true);

    listPays = await MuseeDatabase.instance.getPays();
    print(listPays);
    print(listPays.length);

    setState(() => isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Align(
            alignment: Alignment.topLeft,
            child: Container(
                  height: 35,
                  width: double.infinity,
                  color: const Color(0xFFE6E6E6),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(left: 20),
                        child: const Text('Liste des pays', style: TextStyle(fontWeight: FontWeight.bold),)
                      ),
                      
                    ],
                  ),
                ),
          ),
          
          listPays.isNotEmpty ? Expanded(
            child: ListView.builder(
                scrollDirection: Axis.vertical,
                itemCount: listPays.length,
                shrinkWrap: true,
                itemBuilder: (BuildContext ctxt, int index) {
                  return Padding(
                    padding: const EdgeInsets.all(12),
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_)=> PaysScreen(pays : listPays[index])),)
                          .then((val)=>getPays());
                      },
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: const EdgeInsets.all(7),
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    listPays[index].codePays,
                                    style: const TextStyle(fontSize: 14.0, fontWeight: FontWeight.w600),
                                    ),
                                    const SizedBox(height:2),
                                    Text(listPays[index].nbhabitant.toString(),style: const TextStyle(fontSize: 12.0),),
                                ],
                              ),
                               
                          ),
                          const Divider()
                        ],
                      ),
                    ),
                  );
                },
              ),
          )
            : Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Text("Aucun pays n'a encore été ajouté", style: TextStyle(fontSize: 20, fontWeight:FontWeight.bold,)),
                  const SizedBox(height: 5,),
                  Text("Cliquez sur le bouton du bas pour ajouter un pays", style: TextStyle(color: Colors.grey[600]),),
                ],
              ),
            ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: myColor,
        onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_)=>PaysScreen()),)
              .then((val)=>getPays());
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}