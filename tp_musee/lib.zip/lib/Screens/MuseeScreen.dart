import 'package:flutter/material.dart';
import 'package:tp_musee/Models/Musee.dart';

class MuseeScreen extends StatefulWidget {
  Musee? musee;
  MuseeScreen({ Key? key , this.musee}) : super(key: key);

  @override
  State<MuseeScreen> createState() => _MuseeScreenState();
}

class _MuseeScreenState extends State<MuseeScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}