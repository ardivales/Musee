import 'package:flutter/material.dart';
import 'package:tp_musee/Models/Musee.dart';
import 'package:tp_musee/Screens/MuseeScreen.dart';

import '../Database/MuseeDatabase.dart';
import '../main.dart';

class ListeMusees extends StatefulWidget {
  const ListeMusees({ Key? key }) : super(key: key);

  @override
  State<ListeMusees> createState() => _ListeMuseesState();
}

class _ListeMuseesState extends State<ListeMusees> {

  List<Musee> listMusees = [];
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    getMusees();

  }
  @override
  void dispose(){
    MuseeDatabase.instance.close();
    super.dispose();
  }

  Future getMusees() async{
    setState(() => isLoading = true);

    listMusees = await MuseeDatabase.instance.getMusees();

    setState(() => isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Align(
            alignment: Alignment.topLeft,
            child: Container(
                  height: 35,
                  width: double.infinity,
                  color: const Color(0xFFE6E6E6),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(left: 20),
                        child: const Text('Liste des Musée', style: TextStyle(fontWeight: FontWeight.bold),)
                      ),
                      
                    ],
                  ),
                ),
          ),
          
          listMusees.isNotEmpty ? Expanded(
            child: ListView.builder(
                scrollDirection: Axis.vertical,
                itemCount: listMusees.length,
                shrinkWrap: true,
                itemBuilder: (BuildContext ctxt, int index) {
                  return Padding(
                    padding: const EdgeInsets.all(12),
                    child: InkWell(
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_)=> MuseeScreen(musee : listMusees[index])),)
                          .then((val)=>getMusees());
                      },
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: const EdgeInsets.all(7),
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    listMusees[index].nomMus,
                                    style: const TextStyle(fontSize: 14.0, fontWeight: FontWeight.w600),
                                    ),
                                    const SizedBox(height:2),
                                    Text(listMusees[index].nblivres.toString(),style: const TextStyle(fontSize: 12.0),),
                                ],
                              ),
                               
                          ),
                          const Divider()
                        ],
                      ),
                    ),
                  );
                },
              ),
          )
            : Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Text("Aucun musée n'a encore été ajouté", style: TextStyle(fontSize: 20, fontWeight:FontWeight.bold,)),
                  const SizedBox(height: 5,),
                  Text("Cliquez sur le bouton du bas pour ajouter un musée", style: TextStyle(color: Colors.grey[600]),),
                ],
              ),
            ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: myColor,
        onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_)=>MuseeScreen()),)
              .then((val)=>getMusees());
        },
        child: const Icon(Icons.add),
      ),
    );
  
  }
}