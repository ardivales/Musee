import 'package:flutter/material.dart';

class ListeVisites extends StatefulWidget {
  const ListeVisites({ Key? key }) : super(key: key);

  @override
  State<ListeVisites> createState() => _ListeVisitesState();
}

class _ListeVisitesState extends State<ListeVisites> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}